plugins {
    id("com.android.application")
}

android {
    namespace = "com.goalrider.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.goalrider.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "3.0-alpha1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
